package app.dojo.kohai.whitebelt;

public class WhiteBeltGroup {
    public void startExam() {
        System.out.println("Начать экзамен на белый пояс!");
    }
}