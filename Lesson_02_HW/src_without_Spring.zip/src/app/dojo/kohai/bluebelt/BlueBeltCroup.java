package app.dojo.kohai.bluebelt;

public class BlueBeltCroup {
    public void startExam() {
        System.out.println("Начать экзамен на синий пояс!");
    }
}
