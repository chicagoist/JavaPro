package app.dojo;

public class Judge {
    public void startJudging() {
        System.out.println("Начать судейство экзаменов!");
    }
}
