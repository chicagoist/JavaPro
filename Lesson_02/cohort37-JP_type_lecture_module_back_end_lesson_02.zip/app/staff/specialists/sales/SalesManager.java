package app.staff.specialists.sales;

public class SalesManager {

    public void work() {
        System.out.println("Счета заказчикам отправлены!");
    }
}