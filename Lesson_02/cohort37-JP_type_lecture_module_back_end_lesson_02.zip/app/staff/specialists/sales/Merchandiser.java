package app.staff.specialists.sales;

public class Merchandiser {

    public void work() {
        System.out.println("Витрины оформлены!");
    }
}