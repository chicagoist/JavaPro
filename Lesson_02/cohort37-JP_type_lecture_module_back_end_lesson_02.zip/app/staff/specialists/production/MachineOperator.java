package app.staff.specialists.production;

public class MachineOperator {

    public void work() {
        System.out.println("Продукция произведена!");
    }
}