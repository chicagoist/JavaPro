package app.staff.specialists.production;

public class Storekeeper {

    public void work() {
        System.out.println("Продукция принята на склад!");
    }
}