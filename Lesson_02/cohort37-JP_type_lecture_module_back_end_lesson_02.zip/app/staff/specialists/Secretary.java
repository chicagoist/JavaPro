package app.staff.specialists;

public class Secretary {

    public void work() {
        System.out.println("Документация подготовлена!");
    }
}